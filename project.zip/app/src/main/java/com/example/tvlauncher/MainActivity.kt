package com.example.tvlauncher

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PointF
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var effects: EffectsView
    private lateinit var row: LinearLayout
    private lateinit var scroll: HorizontalScrollView
    private var focusedTile: View? = null

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val moveRunnable = Runnable {
        tilePoint()?.let { effects.moveMain(it.x, it.y) }
    }
    private val idleRunnable = Runnable {
        tilePoint()?.let { effects.startIdle(it.x, it.y, dp(135).toFloat()) }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)

        val root = FrameLayout(this)

        // Wallpaper: put wallpaper.jpg or wallpaper.png in app/src/main/assets/
        val wp = loadBitmap("wallpaper.jpg") ?: loadBitmap("wallpaper.png")
        if (wp != null) {
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(wp)
            root.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        } else {
            root.background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF2E7D32.toInt(), 0xFF0B1F12.toInt())
            )
        }

        // Dark scrim at the bottom so labels are readable
        val scrim = View(this)
        scrim.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x00000000, 0xCC000000.toInt())
        )
        root.addView(scrim, FrameLayout.LayoutParams(MATCH, dp(260), Gravity.BOTTOM))

        // Clock
        val clock = TextClock(this)
        clock.format12Hour = "hh:mm a"
        clock.format24Hour = "HH:mm"
        clock.textSize = 28f
        clock.setTextColor(Color.WHITE)
        val clockLp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END)
        clockLp.setMargins(0, dp(32), dp(48), 0)
        root.addView(clock, clockLp)

        // App row
        row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(48), dp(24), dp(48), dp(24))
        scroll = HorizontalScrollView(this)
        scroll.isHorizontalScrollBarEnabled = false
        scroll.clipToPadding = false
        scroll.addView(row)
        val scrollLp = FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM)
        scrollLp.bottomMargin = dp(24)
        root.addView(scroll, scrollLp)

        // Effects overlay (clones + smoke)
        effects = EffectsView(this, loadSprites())
        root.addView(effects, FrameLayout.LayoutParams(MATCH, MATCH))

        setContentView(root)
        buildTiles()
    }

    private fun buildTiles() {
        val pm = packageManager
        val seen = HashSet<String>()
        val items = ArrayList<Triple<String, Drawable, Intent>>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(q, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || !seen.add(pkg)) continue
                val launch = pm.getLeanbackLaunchIntentForPackage(pkg)
                    ?: pm.getLaunchIntentForPackage(pkg)
                    ?: continue
                items.add(Triple(ri.loadLabel(pm).toString(), ri.loadIcon(pm), launch))
            }
        }
        items.sortBy { it.first.lowercase() }
        for ((label, icon, intent) in items) {
            row.addView(makeTile(label, icon, intent))
        }
        row.post { row.getChildAt(0)?.requestFocus() }
    }

    private fun tileBg(focused: Boolean): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(14).toFloat()
        if (focused) {
            g.setColor(0xDD202020.toInt())
            g.setStroke(dp(3), 0xFFFF9800.toInt())
        } else {
            g.setColor(0x99000000.toInt())
        }
        return g
    }

    private fun makeTile(label: String, icon: Drawable, intent: Intent): View {
        val tile = LinearLayout(this)
        tile.orientation = LinearLayout.VERTICAL
        tile.gravity = Gravity.CENTER_HORIZONTAL
        tile.setPadding(dp(10), dp(12), dp(10), dp(10))
        tile.isFocusable = true
        tile.isClickable = true
        tile.background = tileBg(false)

        val iv = ImageView(this)
        iv.setImageDrawable(icon)
        tile.addView(iv, LinearLayout.LayoutParams(dp(72), dp(72)))

        val tv = TextView(this)
        tv.text = label
        tv.setTextColor(Color.WHITE)
        tv.textSize = 12f
        tv.maxLines = 1
        tv.ellipsize = TextUtils.TruncateAt.END
        tv.gravity = Gravity.CENTER
        val tvLp = LinearLayout.LayoutParams(dp(92), WRAP)
        tvLp.topMargin = dp(6)
        tile.addView(tv, tvLp)

        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.setMargins(dp(8), 0, dp(8), 0)
        tile.layoutParams = lp

        tile.setOnClickListener {
            try {
                startActivity(intent)
            } catch (e: Exception) {
                // ignore apps that fail to launch
            }
        }
        tile.setOnFocusChangeListener { v, has ->
            v.background = tileBg(has)
            val sc = if (has) 1.12f else 1f
            v.animate().scaleX(sc).scaleY(sc).setDuration(150).start()
            if (has) {
                focusedTile = v
                handler.removeCallbacks(moveRunnable)
                handler.postDelayed(moveRunnable, 180)
            }
        }
        return tile
    }

    /** Top-centre of the focused tile, in the effects view's coordinates. */
    private fun tilePoint(): PointF? {
        val t = focusedTile ?: return null
        val a = IntArray(2)
        val b = IntArray(2)
        t.getLocationInWindow(a)
        effects.getLocationInWindow(b)
        return PointF(a[0] - b[0] + t.width / 2f, (a[1] - b[1]).toFloat() - dp(2))
    }

    private fun loadBitmap(name: String): Bitmap? = try {
        assets.open(name).use { BitmapFactory.decodeStream(it) }
    } catch (e: Exception) {
        null
    }

    /** Optional: put clone_1.png, clone_2.png ... in app/src/main/assets/ */
    private fun loadSprites(): List<Bitmap> {
        val names: List<String> = (try {
            assets.list("")?.filter { it.startsWith("clone") && it.endsWith(".png") }?.sorted()
        } catch (e: Exception) {
            null
        }) ?: emptyList()
        return names.mapNotNull { loadBitmap(it) }
    }

    private fun scheduleIdle() {
        handler.removeCallbacks(idleRunnable)
        handler.postDelayed(idleRunnable, 8000)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        effects.stopIdle()
        scheduleIdle()
        return super.dispatchKeyEvent(event)
    }

    override fun onResume() {
        super.onResume()
        scheduleIdle()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(idleRunnable)
        effects.stopIdle()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        scroll.smoothScrollTo(0, 0)
        row.getChildAt(0)?.requestFocus()
    }

    // Home screen: Back should do nothing
    override fun onBackPressed() {}
}
